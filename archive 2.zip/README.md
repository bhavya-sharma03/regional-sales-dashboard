# Regional Sales Performance Dashboard — Project Guide

A self-directed Business Analyst portfolio project using the public **Sample Superstore** dataset (Kaggle). This package gives you everything except the actual dashboard build and final write-up — those last two steps are yours to do hands-on, since that's what you'll speak to in interviews.

## What's in this package
1. `BRD_FRD_Sales_Dashboard.docx` — Business & Functional Requirements Document, user stories, As-Is/To-Be, acceptance criteria
2. `sql_queries.sql` — All SQL queries mapped to each functional requirement
3. `UAT_Test_Log.xlsx` — 8 test cases with one intentional "Fail → Fixed" entry (real UAT logs always have at least one defect — it shows you can find and resolve issues, not just rubber-stamp)
4. This guide

## Your remaining steps

### Step 1 — Get the data
Download the dataset from Kaggle: search **"Sample Superstore dataset"** (try `vivek468/superstore-dataset-final` or `bravehart101/sample-supermarket-dataset`). Free Kaggle account required.

### Step 2 — Run the SQL queries
- Import the CSV into SQLite (`sqlite3 superstore.db`, then `.mode csv` → `.import superstore.csv orders`) or load into MySQL Workbench / any SQL tool.
- Run each query in `sql_queries.sql`. Note the actual numbers you get — you'll quote a couple of these in your case study (e.g., "Tables sub-category showed -$X profit despite $Y in sales").
- **Column name check**: Kaggle CSVs sometimes use spaces ("Sub-Category") instead of underscores. Adjust the SQL column names to match your exact CSV headers if needed.

### Step 3 — Build the Power BI dashboard
Build visuals matching each FR in the BRD:
- KPI cards (FR-01)
- Region/State map or bar chart (FR-02)
- Category/Sub-Category bar chart, sorted by profit (FR-03)
- Discount vs. margin scatter or bar (FR-04)
- Filters/slicers panel (FR-05)
- Monthly trend line (FR-07)

Take 3-4 clean screenshots once it's built — these go in your case study and can be attached to your resume/portfolio link.

### Step 4 — Finalize the UAT log
Actually click through your own dashboard against each test case in `UAT_Test_Log.xlsx`. Update "Actual Result" honestly — if something doesn't match, that's fine, log it as a Fail and fix it. A log with zero failures looks fabricated; one real fix you found and resolved is a better story for interviews.

### Step 5 — Write your 1-page case study
Structure:
- **Problem** (2-3 sentences, pull from Section 2 of the BRD)
- **Approach** (BA process you followed: requirements → SQL validation → dashboard → UAT)
- **Key finding** (a real number from your SQL output — e.g., a specific sub-category or region with surprisingly low margin)
- **Recommendation** (one sentence — what would you tell the VP of Sales to do about it?)

## How to host/share this
- **GitHub repo**: BRD as PDF, SQL file, UAT log, dashboard screenshots, case study as README. This is the strongest option — recruiters can skim a well-formatted README in 30 seconds.
- **PDF portfolio**: Combine case study + screenshots into a single PDF, link from your resume.

## Resume bullet (once complete)
Once you've actually built it, your bullets can cite real figures instead of placeholders. For example, replace the placeholder "18% conversion gap" in the suggested bullet with whatever you actually find in the discount/margin or region analysis — using a real number is what makes it credible if you're asked about it in an interview.
