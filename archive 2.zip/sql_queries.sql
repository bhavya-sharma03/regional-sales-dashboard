-- ============================================================
-- Regional Sales Performance Dashboard
-- SQL Queries for KPI Extraction & Validation
-- Dataset: Sample Superstore (Kaggle)
-- Author: Bhavya Sharma
-- ============================================================
-- NOTE ON SETUP:
-- 1. Download the CSV from Kaggle (vivek468/superstore-dataset-final
--    or bravehart101/sample-supermarket-dataset)
-- 2. Import into SQLite / MySQL as a table named `orders`
--    Expected columns (rename to match your CSV headers if different):
--    Order_ID, Order_Date, Ship_Date, Ship_Mode, Customer_Name,
--    Segment, Country, City, State, Region, Category, Sub_Category,
--    Sales, Quantity, Discount, Profit
--
-- Quick SQLite import (from terminal):
--   sqlite3 superstore.db
--   .mode csv
--   .import superstore.csv orders
-- ============================================================


-- ------------------------------------------------------------
-- FR-01: Summary KPI cards — Total Sales, Profit, Quantity, Orders
-- ------------------------------------------------------------
SELECT
    ROUND(SUM(Sales), 2)          AS total_sales,
    ROUND(SUM(Profit), 2)         AS total_profit,
    SUM(Quantity)                 AS total_quantity,
    COUNT(DISTINCT Order_ID)      AS total_orders,
    ROUND(SUM(Profit) * 100.0 / SUM(Sales), 2) AS overall_profit_margin_pct
FROM orders;


-- ------------------------------------------------------------
-- FR-02: Sales & Profit by Region (used for BR-01 / US-02)
-- ------------------------------------------------------------
SELECT
    Region,
    ROUND(SUM(Sales), 2)   AS total_sales,
    ROUND(SUM(Profit), 2)  AS total_profit,
    ROUND(SUM(Profit) * 100.0 / SUM(Sales), 2) AS profit_margin_pct,
    COUNT(DISTINCT Order_ID) AS order_count
FROM orders
GROUP BY Region
ORDER BY total_sales DESC;


-- ------------------------------------------------------------
-- FR-02 (drill-down): Sales & Profit by State within a Region
-- Replace 'West' with any region to test the filter logic
-- ------------------------------------------------------------
SELECT
    State,
    ROUND(SUM(Sales), 2)  AS total_sales,
    ROUND(SUM(Profit), 2) AS total_profit
FROM orders
WHERE Region = 'West'
GROUP BY State
ORDER BY total_sales DESC;


-- ------------------------------------------------------------
-- FR-03: Sales & Profit by Category and Sub-Category
-- Sorted by profit ascending to surface loss-making lines first
-- (supports US-03: "see which categories are losing money")
-- ------------------------------------------------------------
SELECT
    Category,
    Sub_Category,
    ROUND(SUM(Sales), 2)   AS total_sales,
    ROUND(SUM(Profit), 2)  AS total_profit,
    ROUND(SUM(Profit) * 100.0 / SUM(Sales), 2) AS profit_margin_pct
FROM orders
GROUP BY Category, Sub_Category
ORDER BY total_profit ASC;


-- ------------------------------------------------------------
-- FR-03b: Flag loss-making sub-categories (Acceptance Criteria, Section 9)
-- ------------------------------------------------------------
SELECT
    Category,
    Sub_Category,
    ROUND(SUM(Profit), 2) AS total_profit,
    CASE WHEN SUM(Profit) < 0 THEN 'LOSS - FLAG' ELSE 'OK' END AS flag_status
FROM orders
GROUP BY Category, Sub_Category
HAVING SUM(Profit) < 0
ORDER BY total_profit ASC;


-- ------------------------------------------------------------
-- FR-04: Discount vs. Profit Margin analysis (BR-03 / US-05)
-- Buckets discount into ranges to see margin erosion pattern
-- ------------------------------------------------------------
SELECT
    CASE
        WHEN Discount = 0 THEN '0% (No discount)'
        WHEN Discount > 0 AND Discount <= 0.10 THEN '1-10%'
        WHEN Discount > 0.10 AND Discount <= 0.20 THEN '11-20%'
        WHEN Discount > 0.20 AND Discount <= 0.30 THEN '21-30%'
        ELSE '30%+'
    END AS discount_band,
    COUNT(*) AS order_lines,
    ROUND(SUM(Sales), 2)  AS total_sales,
    ROUND(SUM(Profit), 2) AS total_profit,
    ROUND(SUM(Profit) * 100.0 / SUM(Sales), 2) AS profit_margin_pct
FROM orders
GROUP BY discount_band
ORDER BY MIN(Discount);


-- ------------------------------------------------------------
-- FR-07: Monthly Sales & Profit trend over time
-- Note: Order_Date format depends on import; adjust strftime
-- pattern if your dates are stored as TEXT in DD/MM/YYYY etc.
-- ------------------------------------------------------------
SELECT
    strftime('%Y-%m', Order_Date) AS month,
    ROUND(SUM(Sales), 2)  AS total_sales,
    ROUND(SUM(Profit), 2) AS total_profit
FROM orders
GROUP BY month
ORDER BY month;


-- ------------------------------------------------------------
-- FR-05: Filter combination example — Region + Category + Date range
-- (mirrors what a dashboard slicer combination would query)
-- ------------------------------------------------------------
SELECT
    Region,
    Category,
    ROUND(SUM(Sales), 2)  AS total_sales,
    ROUND(SUM(Profit), 2) AS total_profit
FROM orders
WHERE Region = 'East'
  AND Category = 'Furniture'
  AND Order_Date BETWEEN '2015-01-01' AND '2015-12-31'
GROUP BY Region, Category;


-- ------------------------------------------------------------
-- FR-06 / Data Validation (BR-05): Reconciliation check
-- Use this to confirm dashboard totals match source data exactly
-- Run this and compare manually against the Power BI total
-- ------------------------------------------------------------
SELECT
    COUNT(*)                       AS row_count,
    ROUND(SUM(Sales), 2)           AS total_sales_source,
    ROUND(SUM(Profit), 2)          AS total_profit_source,
    SUM(CASE WHEN Sales IS NULL OR Sales = '' THEN 1 ELSE 0 END)   AS null_sales_rows,
    SUM(CASE WHEN Profit IS NULL OR Profit = '' THEN 1 ELSE 0 END) AS null_profit_rows,
    SUM(CASE WHEN Order_ID IS NULL OR Order_ID = '' THEN 1 ELSE 0 END) AS null_orderid_rows
FROM orders;


-- ------------------------------------------------------------
-- Data quality check: duplicate Order_ID + Product combos
-- (useful UAT step — log any findings as defects in your UAT log)
-- ------------------------------------------------------------
SELECT
    Order_ID,
    COUNT(*) AS line_count
FROM orders
GROUP BY Order_ID
HAVING COUNT(*) > 50   -- adjust threshold based on your data's typical order size
ORDER BY line_count DESC;


-- ------------------------------------------------------------
-- Top 10 most profitable Sub-Categories (good for a quick insight
-- callout in your case study / README)
-- ------------------------------------------------------------
SELECT
    Sub_Category,
    ROUND(SUM(Profit), 2) AS total_profit
FROM orders
GROUP BY Sub_Category
ORDER BY total_profit DESC
LIMIT 10;
